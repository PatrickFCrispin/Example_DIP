﻿using Example_DIP.Enums;

namespace Example_DIP.Contracts
{
    internal interface IMessageServiceFactory
    {
        IMessageService CreateMessageService(MessageTypeEnum messageType);
    }
}
