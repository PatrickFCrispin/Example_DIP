﻿namespace Example_DIP.Contracts
{
    internal interface IMessageService
    {
        void Send();
    }
}
