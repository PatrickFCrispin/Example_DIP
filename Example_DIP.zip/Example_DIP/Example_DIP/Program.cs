﻿using Example_DIP;
using Example_DIP.Contracts;
using Example_DIP.Enums;
using Example_DIP.Factories;
using Example_DIP.Services;
using Microsoft.Extensions.DependencyInjection;

internal class Program
{
    private static void Main(string[] args)
    {
        var serviceProvider = ConfigureServices(MessageTypeEnum.PushNotification);
        var messageSender = new MessageSender(serviceProvider.GetRequiredService<IMessageService>());
        messageSender.Process();

        //Factory Pattern
        //var factory = new MessageServiceFactory();
        //var messageSender = new MessageSender(factory.CreateMessageService(MessageTypeEnum.Email));
        //messageSender.Process();
    }

    private static ServiceProvider ConfigureServices(MessageTypeEnum messageType)
    {
        var serviceCollection = new ServiceCollection();

        switch (messageType)
        {
            case MessageTypeEnum.Email:
                serviceCollection.AddScoped<IMessageService, EmailService>();
                break;
            case MessageTypeEnum.PushNotification:
                serviceCollection.AddScoped<IMessageService, PushNotificationService>();
                break;
            case MessageTypeEnum.SMS:
                serviceCollection.AddScoped<IMessageService, SMSService>();
                break;
            default:
                throw new ArgumentException($"Tipo não suportado: {messageType}.");
        }

        return serviceCollection.BuildServiceProvider();
    }
}