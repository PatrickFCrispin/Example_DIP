﻿using Example_DIP.Contracts;
using Example_DIP.Enums;
using Example_DIP.Services;

namespace Example_DIP.Factories
{
    /* 
        * Vantagens do Factory Pattern: 
        * - Permite a criação de objetos de classe sem expor a lógica de criação.
        * - Facilidade em introduzir a criação de novos objetos de classe.
        * - Permite o uso de polimorfismo ao retornar implementações concretas de abstrações.
    */
    internal class MessageServiceFactory : IMessageServiceFactory
    {
        public IMessageService CreateMessageService(MessageTypeEnum messageType)
        {
            return messageType switch
            {
                MessageTypeEnum.Email => new EmailService(),
                MessageTypeEnum.PushNotification => new PushNotificationService(),
                MessageTypeEnum.SMS => new SMSService(),
                _ => throw new ArgumentException($"Tipo não suportado: {messageType}."),
            };
        }
    }
}
