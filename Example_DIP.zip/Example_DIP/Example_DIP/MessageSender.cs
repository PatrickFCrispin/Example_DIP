﻿using Example_DIP.Contracts;

namespace Example_DIP
{
    internal class MessageSender
    {
        private readonly IMessageService _messageService;

        public MessageSender(IMessageService messageService)
        {
            _messageService = messageService;
        }

        public void Process()
        {
            _messageService.Send();
        }
    }
}
