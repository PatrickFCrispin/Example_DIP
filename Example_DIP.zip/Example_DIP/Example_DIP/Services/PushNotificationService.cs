﻿using Example_DIP.Contracts;

namespace Example_DIP.Services
{
    internal class PushNotificationService : IMessageService
    {
        public void Send()
        {
            Console.WriteLine($"Enviando Push Notification...");
            Console.WriteLine($"Push Notification enviado!");
        }
    }
}
