﻿using Example_DIP.Contracts;

namespace Example_DIP.Services
{
    internal class SMSService : IMessageService
    {
        public void Send()
        {
            Console.WriteLine($"Enviando SMS...");
            Console.WriteLine($"SMS enviado!");
        }
    }
}
