﻿using Example_DIP.Contracts;

namespace Example_DIP.Services
{
    internal class EmailService : IMessageService
    {
        public void Send()
        {
            Console.WriteLine("Enviado E-mail...");
            Console.WriteLine("E-mail enviado!");
        }
    }
}
