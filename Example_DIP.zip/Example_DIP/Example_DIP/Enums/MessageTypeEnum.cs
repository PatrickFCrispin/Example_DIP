﻿namespace Example_DIP.Enums
{
    enum MessageTypeEnum
    {
        Email,
        PushNotification,
        SMS,
    }
}
